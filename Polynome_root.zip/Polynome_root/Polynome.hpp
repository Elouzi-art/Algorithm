#ifndef POLYNOME_H
#define POLYNOME_H

#include <iostream>
#include <stdexcept>

typedef struct Monome {
    int exp;
    int coef;
} Monome;

typedef struct Node {
    Monome monome;
    struct Node* next;
    struct Node* prev;
} Node;

class Polynome {
private:
    Node* head;
    Node* tail;

public:
    Polynome();
    Polynome(int n);
    Polynome(const Polynome& other);
    Polynome& operator=(const Polynome& other);
    Node* create_node(int a_k, int k);
    void  create_polynome(int a_k, int k);
    void  free_polynome();
    int   get_coef() const;
    int   get_exp()  const;

    Polynome& operator+=(const Polynome& p2);

    friend Polynome operator+(const Polynome& p1, const Polynome& p2);
    friend Polynome operator*(const Polynome& p1, const Polynome& p2);

    void   root_R(double a, double b, double epsilon = 1e-4);
    double image(double x);
    void  display();

    ~Polynome();
};

#endif