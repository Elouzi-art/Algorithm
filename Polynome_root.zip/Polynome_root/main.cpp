#include "Polynome.hpp"



int main() {
    try {
        int n1, n2;

        std::cout << "=== Polynomial 1 ===" << std::endl;
        std::cout << "Number of monomials: ";
        std::cin >> n1;
        Polynome p1(n1);

        std::cout << "\n=== Polynomial 2 ===" << std::endl;
        std::cout << "Number of monomials: ";
        std::cin >> n2;
        Polynome p2(n2);

        std::cout << "\n=== Display ===" << std::endl;
        std::cout << "P1 -> "; p1.display();
        std::cout << "P2 -> "; p2.display();

        std::cout << "\n=== Addition ===" << std::endl;
        Polynome sum = p1 + p2;
        std::cout << "P1 + P2 -> "; sum.display();

        std::cout << "\n=== Multiplication ===" << std::endl;
        Polynome product = p1 * p2;
        std::cout << "P1 * P2 -> "; product.display();

        std::cout << "\n=== Roots of P1 + P2 ===" << std::endl;
        double a, b;
        std::cout << "Enter interval [a, b]" << std::endl;
        std::cout << "a: "; std::cin >> a;
        std::cout << "b: "; std::cin >> b;
        if (a >= b)
            throw std::invalid_argument("Error: a must be less than b.");
        std::cout << "Roots of (P1 + P2):" << std::endl;
        sum.root_R(a, b);

        std::cout << "\n=== Roots of P1 * P2 ===" << std::endl;
        std::cout << "Roots of (P1 * P2):" << std::endl;
        product.root_R(a, b);

    } catch (const std::exception& e) {
        std::cerr << e.what() << std::endl;
        return 1;
    }

    return 0;
}