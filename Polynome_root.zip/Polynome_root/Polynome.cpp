#include "Polynome.hpp"
#include <cmath>

Polynome::Polynome() : head(nullptr), tail(nullptr) {}

Polynome::Polynome(int n) : head(nullptr), tail(nullptr) {
    for (int i = 0; i < n; ++i) {
        int coef, exp;
        std::cout << "Monomial #" << i + 1 << ", Enter coefficient: ";
        std::cin >> coef;
        std::cout << "Monomial #" << i + 1 << ", Enter exponent: ";
        std::cin >> exp;
        if (exp < 0)
            throw std::invalid_argument("Error: exponent cannot be negative.");
        create_polynome(coef, exp);
    }
}

Polynome::Polynome(const Polynome& other) : head(nullptr), tail(nullptr) {
    Node* current = other.head;
    while (current != nullptr) {
        create_polynome(current->monome.coef, current->monome.exp);
        current = current->next;
    }
}

Polynome& Polynome::operator=(const Polynome& other) {
    if (this == &other) return *this;
    free_polynome();
    Node* current = other.head;
    while (current != nullptr) {
        create_polynome(current->monome.coef, current->monome.exp);
        current = current->next;
    }
    return *this;
}

Node* Polynome::create_node(int a_k, int k) {
    Node* node    = new Node();
    node->monome.coef = a_k;
    node->monome.exp  = k;
    node->next    = nullptr;
    node->prev    = nullptr;
    return node;
}


void Polynome::create_polynome(int a_k, int k){

	Node* new_node = create_node(a_k, k);

	if(!head){
		head = tail = new_node;
		return;
	}

	Node* current = head;
	while(current != nullptr && current->monome.exp > k)
		current = current->next;

	if(current == nullptr){

		new_node->prev= tail;
		tail->next = new_node;
		tail = new_node;
		return;
	}

	if(current->monome.exp == k){

		current->monome.exp += a_k;
		if(current->monome.exp == 0){

			if(current->prev) current->prev->next = current->next;
			else head = current->next;
			if(current->next) current->next->prev = current->prev;
			else tail = current->prev;
			delete current;
		}
		delete new_node;
		return;
	}

	new_node->next = current;
	new_node->prev = current->prev;
	if(new_node->prev) current->prev->next = new_node;
	else head = new_node;
	current->prev = new_node;

}



void Polynome::free_polynome() {
    Node* current = head;
    while (current != nullptr) {
        Node* next_node = current->next;
        delete current;
        current = next_node;
    }
    head = tail = nullptr;
}

int Polynome::get_coef() const { return head->monome.coef; }
int Polynome::get_exp()  const { return head->monome.exp;  }

Polynome operator+(const Polynome& p1, const Polynome& p2) {
    Polynome result;

    if (p2.head == nullptr) return p1;
    if (p1.head == nullptr) return p2;

    Node* cur1 = p1.head;
    Node* cur2 = p2.head;

    while (cur1 != nullptr && cur2 != nullptr) {
        if (cur1->monome.exp == cur2->monome.exp) {
            int sum = cur1->monome.coef + cur2->monome.coef;
            if (sum != 0)
                result.create_polynome(sum, cur1->monome.exp);
            cur1 = cur1->next;
            cur2 = cur2->next;
        } else if (cur1->monome.exp > cur2->monome.exp) {
            result.create_polynome(cur1->monome.coef, cur1->monome.exp);
            cur1 = cur1->next;
        } else {
            result.create_polynome(cur2->monome.coef, cur2->monome.exp);
            cur2 = cur2->next;
        }
    }

    while (cur1 != nullptr) {
        result.create_polynome(cur1->monome.coef, cur1->monome.exp);
        cur1 = cur1->next;
    }
    while (cur2 != nullptr) {
        result.create_polynome(cur2->monome.coef, cur2->monome.exp);
        cur2 = cur2->next;
    }

    return result;
}

Polynome operator*(const Polynome& p1, const Polynome& p2) {
    Polynome result;

    if (p1.head == nullptr || p2.head == nullptr) return result;

    Node* cur1 = p1.head;
    while (cur1 != nullptr) {
        Node* cur2 = p2.head;
        while (cur2 != nullptr) {
            int tmp_coef = cur1->monome.coef * cur2->monome.coef;
            int tmp_exp  = cur1->monome.exp  + cur2->monome.exp;
            result.create_polynome(tmp_coef, tmp_exp);
            cur2 = cur2->next;
        }
        cur1 = cur1->next;
    }

    return result;
}

Polynome& Polynome::operator+=(const Polynome& p2) {
    *this = *this + p2;
    return *this;
}

void Polynome::display() {
    Node* current = head;
    if (current == nullptr) {
        std::cout << "0" << std::endl;
        return;
    }
    std::cout << "Forward  : ";
    while (current != nullptr) {
        std::cout << current->monome.coef << "X^" << current->monome.exp;
        if (current->next != nullptr) std::cout << " + ";
        current = current->next;
    }
    std::cout << std::endl;

    current = tail;
    std::cout << "Backward : ";
    while (current != nullptr) {
        std::cout << current->monome.coef << "X^" << current->monome.exp;
        if (current->prev != nullptr) std::cout << " + ";
        current = current->prev;
    }
    std::cout << std::endl;
}



void Polynome::root_R(double a, double b, double epsilon) {
    // Adapter epsilon à la taille de l'intervalle pour éviter trop d'itérations
    double range = b - a;
    double step  = epsilon;
    if (range / step > 1000000.0)
        step = range / 1000000.0;

    int index = 0;
    for (double left = a; left < b; left += step) {
        double right = left + step;
        if (right > b) right = b;
        double fl = image(left);
        double fr = image(right);
        if (fl * fr < 0)
            std::cout << "x" << ++index << " in [" << left << ", " << right << "]\n";
    }

    if (index == 0)
        std::cout << "No roots found in [" << a << ", " << b << "]" << std::endl;
}

double Polynome::image(double x) {
    Node*  current = head;
    double result  = 0.0;
    while (current != nullptr) {
        result += current->monome.coef * std::pow(x, current->monome.exp);
        current = current->next;
    }
    return result;
}

Polynome::~Polynome() {
    free_polynome();
}